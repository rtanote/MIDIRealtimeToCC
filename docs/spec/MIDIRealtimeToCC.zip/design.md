# Design: MIDIRealtimeToCC

## Overview

本ドキュメントは MIDIRealtimeToCC アプリケーションの技術設計を定義する。

---

## Architecture

### System Context

```
┌─────────────────────┐
│   MIDI Controller   │
│   (例: Roland A-70) │
└──────────┬──────────┘
           │ USB/MIDI
           ▼
┌──────────────────────────────────────────┐
│              macOS                        │
│  ┌────────────────────────────────────┐  │
│  │           CoreMIDI                  │  │
│  └──────────────┬─────────────────────┘  │
│                 │                         │
│  ┌──────────────▼─────────────────────┐  │
│  │       MIDIRealtimeToCC             │  │
│  │  ┌─────────┐  ┌─────────────────┐  │  │
│  │  │ Input   │  │ Message         │  │  │
│  │  │ Handler │─▶│ Processor       │  │  │
│  │  └─────────┘  └────────┬────────┘  │  │
│  │                        │           │  │
│  │               ┌────────▼────────┐  │  │
│  │               │ Output Handler  │  │  │
│  │               └────────┬────────┘  │  │
│  └────────────────────────┼───────────┘  │
│                           │              │
│  ┌────────────────────────▼───────────┐  │
│  │           IAC Driver               │  │
│  └────────────────────────┬───────────┘  │
│                           │              │
│  ┌────────────────────────▼───────────┐  │
│  │           Logic Pro                │  │
│  └────────────────────────────────────┘  │
└──────────────────────────────────────────┘
```

### Component Architecture

```
MIDIRealtimeToCC
├── Core/
│   ├── MIDIManager          # CoreMIDI接続管理
│   ├── MessageProcessor     # メッセージ変換ロジック
│   └── ConversionRules      # 変換ルール定義
├── CLI/
│   └── CommandLineParser    # CLI引数処理
└── UI/ (Phase 2)
    ├── MenuBarApp           # メニューバーアプリ
    ├── SettingsView         # 設定画面
    └── DeviceSelector       # デバイス選択UI
```

---

## Data Flow

### Message Processing Sequence

```
┌──────────┐     ┌─────────────┐     ┌──────────────────┐     ┌──────────┐
│  Input   │     │   MIDI      │     │    Message       │     │  Output  │
│  Device  │     │  Manager    │     │   Processor      │     │  Device  │
└────┬─────┘     └──────┬──────┘     └────────┬─────────┘     └────┬─────┘
     │                  │                      │                    │
     │  MIDI Message    │                      │                    │
     │─────────────────▶│                      │                    │
     │                  │                      │                    │
     │                  │  Raw Bytes           │                    │
     │                  │─────────────────────▶│                    │
     │                  │                      │                    │
     │                  │                      │ Check message type │
     │                  │                      │◀─────────────────┐ │
     │                  │                      │                  │ │
     │                  │                      │─────────────────▶│ │
     │                  │                      │                    │
     │                  │                      │ [Conversion Target]│
     │                  │                      │ Convert to CC      │
     │                  │                      │────────────────────▶
     │                  │                      │                    │
     │                  │                      │ [Pass-through]     │
     │                  │                      │ Forward unchanged  │
     │                  │                      │────────────────────▶
     │                  │                      │                    │
```

### Conversion Decision Flow

```
                    ┌─────────────────┐
                    │ Receive Message │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │ Get Status Byte │
                    └────────┬────────┘
                             │
          ┌──────────────────┼──────────────────┐
          │                  │                  │
    ┌─────▼─────┐     ┌──────▼──────┐    ┌─────▼─────┐
    │ 0xFA/FB/FC│     │    0xF2     │    │   0xF3    │
    │ Start/    │     │ Song Pos    │    │ Song Sel  │
    │ Continue/ │     └──────┬──────┘    └─────┬─────┘
    │ Stop      │            │                 │
    └─────┬─────┘     ┌──────▼──────┐   ┌──────▼──────┐
          │          │ Position=0? │   │ Compare to  │
    ┌─────▼─────┐     └──────┬──────┘   │ Previous    │
    │ Output    │            │          └──────┬──────┘
    │ CC 80     │     ┌──────┴──────┐          │
    └───────────┘     │Yes      No  │   ┌──────┴──────┐
                      ▼             ▼   │Inc    Dec   │
               ┌──────────┐  ┌──────┐   ▼             ▼
               │Output    │  │ Pass │  ┌────────┐ ┌────────┐
               │CC 82     │  │through│ │Output  │ │Output  │
               └──────────┘  └──────┘  │CC 83   │ │CC 84   │
                                       └────────┘ └────────┘
```

---

## Technical Specifications

### CoreMIDI Integration

#### Client Setup

```swift
var midiClient: MIDIClientRef = 0
var inputPort: MIDIPortRef = 0
var outputPort: MIDIPortRef = 0

// クライアント作成
MIDIClientCreate("MIDIRealtimeToCC" as CFString, notifyCallback, nil, &midiClient)

// 入力ポート作成
MIDIInputPortCreate(midiClient, "Input" as CFString, readCallback, nil, &inputPort)

// 出力ポート作成
MIDIOutputPortCreate(midiClient, "Output" as CFString, &outputPort)
```

#### Read Callback

```swift
let readCallback: MIDIReadProc = { packetList, srcConnRefCon, connRefCon in
    let packets = packetList.pointee
    var packet = packets.packet
    
    for _ in 0..<packets.numPackets {
        let bytes = Mirror(reflecting: packet.data).children.map { $0.value as! UInt8 }
        let length = Int(packet.length)
        
        processMessage(Array(bytes.prefix(length)))
        
        packet = MIDIPacketNext(&packet).pointee
    }
}
```

### Message Format

#### Input Messages

| Message | Status | Data Bytes | Total |
|---------|--------|------------|-------|
| Start | 0xFA | none | 1 |
| Continue | 0xFB | none | 1 |
| Stop | 0xFC | none | 1 |
| Song Position | 0xF2 | LSB, MSB | 3 |
| Song Select | 0xF3 | song number | 2 |

#### Output Messages

| Message | Status | Data 1 | Data 2 | Total |
|---------|--------|--------|--------|-------|
| CC | 0xB0 | CC number | value | 3 |

### Conversion Rules

```swift
struct ConversionRule {
    let inputStatus: UInt8
    let outputCC: UInt8
    let outputValue: UInt8
    let condition: ((Data) -> Bool)?
}

let defaultRules: [ConversionRule] = [
    // Start → CC 80, value 127
    ConversionRule(inputStatus: 0xFA, outputCC: 80, outputValue: 127, condition: nil),
    
    // Continue → CC 80, value 127
    ConversionRule(inputStatus: 0xFB, outputCC: 80, outputValue: 127, condition: nil),
    
    // Stop → CC 80, value 0
    ConversionRule(inputStatus: 0xFC, outputCC: 80, outputValue: 0, condition: nil),
    
    // Song Position (pos=0) → CC 82, value 127
    ConversionRule(inputStatus: 0xF2, outputCC: 82, outputValue: 127, 
                   condition: { $0[1] == 0 && $0[2] == 0 }),
]
```

### State Management

```swift
class ConverterState {
    var lastSongNumber: UInt8? = nil
    var isEnabled: Bool = true
    
    func processSongSelect(_ songNumber: UInt8) -> ConversionResult? {
        defer { lastSongNumber = songNumber }
        
        guard let previous = lastSongNumber else {
            return nil  // 初回は出力なし
        }
        
        if songNumber > previous {
            return .init(cc: 83, value: 127)  // 増加 → 次のマーカー
        } else if songNumber < previous {
            return .init(cc: 84, value: 127)  // 減少 → 前のマーカー
        }
        return nil  // 同値は無視
    }
}
```

---

## Configuration

### Phase 1: CLI Arguments

```
Usage: MIDIRealtimeToCC [options]

Options:
  --list              List available MIDI devices
  --input <name>      Specify input device name
  --output <name>     Specify output device name
  --help              Show help message
  --version           Show version information
```

### Phase 2: UserDefaults Schema

| Key | Type | Description |
|-----|------|-------------|
| `inputDeviceUID` | String | 入力デバイスのユニークID |
| `outputDeviceUID` | String | 出力デバイスのユニークID |
| `ccStart` | Int | Start/Continue の出力CC番号 |
| `ccStop` | Int | Stop の出力CC番号 |
| `ccSongPosition` | Int | Song Position Reset の出力CC番号 |
| `ccNextMarker` | Int | Song Select増加時の出力CC番号 |
| `ccPrevMarker` | Int | Song Select減少時の出力CC番号 |
| `launchAtLogin` | Bool | ログイン時自動起動 |

---

## Error Handling

### Device Connection Errors

| Error | Handling |
|-------|----------|
| Device not found | エラーメッセージを表示し終了 (CLI) / アラート表示 (UI) |
| Device disconnected | 再接続を試行、失敗時は通知 |
| Permission denied | システム環境設定への誘導メッセージ |

### Runtime Errors

| Error | Handling |
|-------|----------|
| CoreMIDI initialization failure | エラーログ出力、終了 |
| Output send failure | エラーログ出力、処理継続 |

---

## Performance Considerations

### Latency Budget

| Component | Target | Notes |
|-----------|--------|-------|
| CoreMIDI callback | < 100μs | システム依存 |
| Message processing | < 50μs | 単純な条件分岐のみ |
| Output send | < 100μs | システム依存 |
| **Total** | **< 1ms** | 人間の知覚閾値以下 |

### Memory Usage

| Component | Estimate |
|-----------|----------|
| CoreMIDI resources | ~5MB |
| Application code | ~2MB |
| UI resources (Phase 2) | ~10MB |
| **Total** | **< 50MB** |

---

## Security Considerations

### macOS Permissions

- **Input Monitoring**: MIDI入力デバイスへのアクセスに必要
- **Automation**: 不要（他アプリの制御なし）

### Code Signing

Phase 2のUI版配布時に必要：
- Developer ID Application 証明書
- Notarization (公証)

---

## Testing Strategy

### Unit Tests

- `ConversionRules`: 各変換ルールの入出力検証
- `ConverterState`: Song Select の状態遷移検証
- `MessageProcessor`: メッセージ判定ロジック検証

### Integration Tests

- CoreMIDI 接続・切断シナリオ
- IAC Driver 経由のメッセージ送受信
- デバイスホットプラグ対応

### Manual Tests

- 実機 (Roland A-70) との動作確認
- Logic Pro での MIDI Learn 動作確認
