# Tasks: MIDIRealtimeToCC

## Phase 1: CLI版

### Task 1: プロジェクトセットアップ

- [ ] **1.1** Xcode プロジェクト作成
  - macOS Command Line Tool テンプレートを使用
  - Swift 言語を選択
  - プロジェクト名: MIDIRealtimeToCC
  - Bundle Identifier: com.example.MIDIRealtimeToCC

- [ ] **1.2** CoreMIDI フレームワーク追加
  - Linked Frameworks に CoreMIDI.framework を追加
  - `import CoreMIDI` の動作確認

- [ ] **1.3** プロジェクト構造作成
  ```
  MIDIRealtimeToCC/
  ├── main.swift
  ├── Core/
  │   ├── MIDIManager.swift
  │   ├── MessageProcessor.swift
  │   └── ConversionRules.swift
  └── CLI/
      └── CommandLineParser.swift
  ```

### Task 2: MIDIManager 実装

- [ ] **2.1** MIDIClient 初期化
  - `MIDIClientCreate` でクライアント作成
  - 通知コールバックの設定
  - エラーハンドリング実装

- [ ] **2.2** デバイス列挙機能
  - `MIDIGetNumberOfSources()` / `MIDIGetSource()` で入力デバイス取得
  - `MIDIGetNumberOfDestinations()` / `MIDIGetDestination()` で出力デバイス取得
  - デバイス名取得 (`kMIDIPropertyName`)

- [ ] **2.3** 入力ポート作成
  - `MIDIInputPortCreate` でポート作成
  - 読み取りコールバック実装
  - デバイスへの接続 (`MIDIPortConnectSource`)

- [ ] **2.4** 出力ポート作成
  - `MIDIOutputPortCreate` でポート作成
  - メッセージ送信メソッド実装
  - `MIDISend` のラッパー作成

- [ ] **2.5** デバイス接続/切断
  - 名前指定でのデバイス検索
  - 接続エラーハンドリング
  - 切断時のクリーンアップ

### Task 3: MessageProcessor 実装

- [ ] **3.1** メッセージ解析基盤
  - ステータスバイト判定
  - データバイト抽出
  - メッセージ長検証

- [ ] **3.2** リアルタイムメッセージ処理
  - 0xFA (Start) 検出と変換
  - 0xFB (Continue) 検出と変換
  - 0xFC (Stop) 検出と変換

- [ ] **3.3** Song Position 処理
  - 0xF2 検出
  - LSB/MSB からポジション値計算
  - ポジション 0 の判定

- [ ] **3.4** Song Select 処理
  - 0xF3 検出
  - 前回値との比較ロジック
  - 状態保持 (lastSongNumber)

- [ ] **3.5** パススルー処理
  - 非変換対象メッセージの判定
  - そのまま出力への転送

### Task 4: ConversionRules 実装

- [ ] **4.1** 変換ルール構造体定義
  ```swift
  struct ConversionRule {
      let inputStatus: UInt8
      let outputCC: UInt8
      let outputValue: UInt8
      let condition: ((Data) -> Bool)?
  }
  ```

- [ ] **4.2** デフォルトルール定義
  - Start/Continue → CC 80, value 127
  - Stop → CC 80, value 0
  - Song Position (0) → CC 82, value 127
  - Song Select 増加 → CC 83, value 127
  - Song Select 減少 → CC 84, value 127

- [ ] **4.3** CC メッセージ生成
  - ステータスバイト (0xB0 + channel)
  - CC 番号バイト
  - 値バイト
  - MIDIPacket 作成

### Task 5: CommandLineParser 実装

- [ ] **5.1** 引数パース基盤
  - `CommandLine.arguments` 処理
  - フラグとオプション値の分離

- [ ] **5.2** --list 実装
  - 入力デバイス一覧表示
  - 出力デバイス一覧表示
  - フォーマット整形

- [ ] **5.3** --input / --output 実装
  - デバイス名の取得
  - 空白を含む名前の対応
  - 存在確認

- [ ] **5.4** --help 実装
  - 使用方法表示
  - オプション説明

- [ ] **5.5** エラーハンドリング
  - 不正な引数のエラーメッセージ
  - 必須引数チェック
  - 終了コード設定

### Task 6: main.swift 統合

- [ ] **6.1** 初期化シーケンス
  - 引数パース
  - MIDIManager 初期化
  - デバイス接続

- [ ] **6.2** メインループ
  - RunLoop でのイベント待機
  - シグナルハンドリング (Ctrl+C)

- [ ] **6.3** ログ出力
  - 起動メッセージ
  - 変換ログ (タイムスタンプ付き)
  - エラーログ

- [ ] **6.4** 終了処理
  - デバイス切断
  - CoreMIDI リソース解放

### Task 7: テストとデバッグ

- [ ] **7.1** 単体動作確認
  - デバイス一覧表示確認
  - 接続/切断確認

- [ ] **7.2** 変換動作確認
  - MIDI Monitor 等で入力確認
  - IAC Driver 経由で出力確認
  - 各メッセージタイプの変換検証

- [ ] **7.3** Logic Pro 連携確認
  - MIDI Learn での CC 認識
  - トランスポート制御動作
  - レイテンシ体感確認

---

## Phase 2: メニューバーUI版

### Task 8: SwiftUI アプリ構造

- [ ] **8.1** プロジェクト変更
  - macOS App テンプレートに変更
  - SwiftUI ライフサイクル選択
  - LSUIElement = YES 設定 (Dockアイコン非表示)

- [ ] **8.2** MenuBarExtra 実装
  - `MenuBarExtra` ビュー作成
  - ステータスアイコン設定
  - メニュー構造定義

- [ ] **8.3** Core モジュール統合
  - Phase 1 の Core/ を再利用
  - UI との連携インターフェース

### Task 9: デバイス選択UI

- [ ] **9.1** DeviceSelector ビュー
  - Picker でデバイス選択
  - 入力/出力それぞれ表示
  - 選択状態のバインディング

- [ ] **9.2** デバイスリスト更新
  - ホットプラグ対応
  - リスト自動更新

### Task 10: 設定画面

- [ ] **10.1** SettingsView 作成
  - CC 番号入力フィールド
  - 各変換ルールの設定
  - バリデーション表示

- [ ] **10.2** UserDefaults 連携
  - @AppStorage での永続化
  - 設定読み込み/保存

- [ ] **10.3** ログイン時起動設定
  - ServiceManagement フレームワーク
  - LaunchAtLogin 切り替え

### Task 11: 状態表示

- [ ] **11.1** 接続状態表示
  - 接続中/切断のアイコン変更
  - ツールチップ表示

- [ ] **11.2** アクティビティ表示
  - メッセージ受信時の視覚フィードバック
  - 最終変換ログ表示

### Task 12: 配布準備

- [ ] **12.1** コード署名
  - Developer ID 証明書設定
  - Hardened Runtime 有効化

- [ ] **12.2** Notarization
  - Apple 公証提出
  - Stapling

- [ ] **12.3** DMG 作成
  - アプリバンドル
  - インストール手順

---

## Acceptance Checklist

### Phase 1 完了条件

- [ ] `--list` でデバイス一覧が表示される
- [ ] 指定したデバイスに接続できる
- [ ] Start (0xFA) → CC 80, 127 に変換される
- [ ] Continue (0xFB) → CC 80, 127 に変換される
- [ ] Stop (0xFC) → CC 80, 0 に変換される
- [ ] Song Position (0) → CC 82, 127 に変換される
- [ ] Song Select 増加 → CC 83, 127 に変換される
- [ ] Song Select 減少 → CC 84, 127 に変換される
- [ ] 非変換対象メッセージがパススルーされる
- [ ] Logic Pro で MIDI Learn できる

### Phase 2 完了条件

- [ ] メニューバーに常駐する
- [ ] UI からデバイス選択できる
- [ ] CC 番号をカスタマイズできる
- [ ] 設定が再起動後も保持される
- [ ] ログイン時自動起動が設定できる
- [ ] 署名・公証済み DMG が作成できる
