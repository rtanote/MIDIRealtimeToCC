# Requirements: MIDIRealtimeToCC

## Overview

MIDIリアルタイムメッセージをControl Change (CC) メッセージに変換し、DAWのトランスポート制御をMIDIコントローラーから行えるようにするmacOSアプリケーション。

---

## User Stories

### US-1: 再生/停止制御

**As a** DAWユーザー  
**I want to** MIDIコントローラーのSTART/STOPボタンでDAWの再生/停止を制御したい  
**So that** コンピュータから離れた位置でも録音作業ができる

#### Acceptance Criteria

- AC-1.1: Start メッセージの変換
  ```
  WHEN the application receives MIDI Real-time Start message (0xFA)
  THE SYSTEM SHALL output CC 80 with value 127 on channel 1
  ```

- AC-1.2: Continue メッセージの変換
  ```
  WHEN the application receives MIDI Real-time Continue message (0xFB)
  THE SYSTEM SHALL output CC 80 with value 127 on channel 1
  ```

- AC-1.3: Stop メッセージの変換
  ```
  WHEN the application receives MIDI Real-time Stop message (0xFC)
  THE SYSTEM SHALL output CC 80 with value 0 on channel 1
  ```

---

### US-2: 曲頭への移動

**As a** DAWユーザー  
**I want to** MIDIコントローラーのRESETボタンで再生位置を曲頭に戻したい  
**So that** 録音のやり直しが素早くできる

#### Acceptance Criteria

- AC-2.1: Song Position Reset の変換
  ```
  WHEN the application receives Song Position Pointer message (0xF2) with position 0
  THE SYSTEM SHALL output CC 82 with value 127 on channel 1
  ```

- AC-2.2: 非ゼロポジションの無視
  ```
  WHEN the application receives Song Position Pointer message (0xF2) with non-zero position
  THE SYSTEM SHALL NOT output any CC message
  ```

---

### US-3: マーカー間移動

**As a** DAWユーザー  
**I want to** SONG SELECTボタンで前後のマーカーに移動したい  
**So that** 曲の特定のセクションに素早くアクセスできる

#### Acceptance Criteria

- AC-3.1: Song Select 増加時の変換
  ```
  WHEN the application receives Song Select message (0xF3) with song number greater than previous
  THE SYSTEM SHALL output CC 83 with value 127 on channel 1
  ```

- AC-3.2: Song Select 減少時の変換
  ```
  WHEN the application receives Song Select message (0xF3) with song number less than previous
  THE SYSTEM SHALL output CC 84 with value 127 on channel 1
  ```

- AC-3.3: Song Select 状態の記憶
  ```
  WHEN the application receives Song Select message (0xF3)
  THE SYSTEM SHALL store the song number for comparison with subsequent messages
  ```

- AC-3.4: 初回 Song Select の処理
  ```
  WHEN the application receives the first Song Select message after startup
  THE SYSTEM SHALL store the song number without outputting any CC message
  ```

---

### US-4: MIDIパススルー

**As a** DAWユーザー  
**I want to** 変換対象外のMIDIメッセージがそのまま転送されてほしい  
**So that** 演奏データ（ノート、CC、ピッチベンド等）が失われない

#### Acceptance Criteria

- AC-4.1: ノートメッセージのパススルー
  ```
  WHEN the application receives Note On or Note Off messages
  THE SYSTEM SHALL forward them unchanged to the output device
  ```

- AC-4.2: CCメッセージのパススルー
  ```
  WHEN the application receives Control Change messages
  THE SYSTEM SHALL forward them unchanged to the output device
  ```

- AC-4.3: その他のメッセージのパススルー
  ```
  WHEN the application receives any MIDI message not specified for conversion
  THE SYSTEM SHALL forward it unchanged to the output device
  ```

---

### US-5: デバイス選択 (CLI)

**As a** ユーザー  
**I want to** コマンドラインから入力・出力MIDIデバイスを指定したい  
**So that** 自分の環境に合わせて使用できる

#### Acceptance Criteria

- AC-5.1: デバイス一覧表示
  ```
  WHEN the user runs the application with --list flag
  THE SYSTEM SHALL display all available MIDI input and output devices
  ```

- AC-5.2: 入力デバイス指定
  ```
  WHEN the user specifies --input with a device name
  THE SYSTEM SHALL connect to that device as MIDI input source
  ```

- AC-5.3: 出力デバイス指定
  ```
  WHEN the user specifies --output with a device name
  THE SYSTEM SHALL connect to that device as MIDI output destination
  ```

- AC-5.4: 無効なデバイス名のエラー処理
  ```
  WHEN the user specifies a device name that does not exist
  THE SYSTEM SHALL display an error message and exit with non-zero status
  ```

---

### US-6: メニューバーUI (Phase 2)

**As a** ユーザー  
**I want to** メニューバーからアプリケーションを制御したい  
**So that** GUIで簡単に設定や状態確認ができる

#### Acceptance Criteria

- AC-6.1: メニューバー常駐
  ```
  WHEN the application is running
  THE SYSTEM SHALL display an icon in the macOS menu bar
  ```

- AC-6.2: デバイス選択UI
  ```
  WHEN the user clicks the menu bar icon
  THE SYSTEM SHALL display a menu with input and output device selection
  ```

- AC-6.3: 設定の永続化
  ```
  WHEN the user selects input or output devices
  THE SYSTEM SHALL persist the selection and restore it on next launch
  ```

---

### US-7: CC番号カスタマイズ (Phase 2)

**As a** ユーザー  
**I want to** 出力するCC番号を変更したい  
**So that** 既存のCC割り当てと競合しないようにできる

#### Acceptance Criteria

- AC-7.1: CC番号設定UI
  ```
  WHEN the user opens the settings panel
  THE SYSTEM SHALL display CC number fields for each conversion rule
  ```

- AC-7.2: CC番号の範囲検証
  ```
  WHEN the user enters a CC number outside 0-127
  THE SYSTEM SHALL display a validation error and reject the input
  ```

- AC-7.3: CC設定の永続化
  ```
  WHEN the user changes CC number settings
  THE SYSTEM SHALL persist the settings and apply them immediately
  ```

---

## Out of Scope

- MIDI 2.0 プロトコルのサポート
- Windows/Linux 対応
- 複数入力デバイスの同時使用
- Audio Unit / MIDI FX プラグイン形式
